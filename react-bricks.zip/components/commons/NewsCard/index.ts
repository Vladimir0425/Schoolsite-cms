export * from './NewsCard'
