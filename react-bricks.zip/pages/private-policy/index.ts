export { PrivatePolicy as default } from './PrivatePolicy'
