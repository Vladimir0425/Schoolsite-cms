export { EventDetail as default } from './EventDetail'
