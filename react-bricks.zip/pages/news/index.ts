export { News as default } from './News'
