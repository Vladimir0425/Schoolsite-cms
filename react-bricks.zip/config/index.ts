export const SERVER_URL = 'https://plankton-app-vkwlv.ondigitalocean.app'
