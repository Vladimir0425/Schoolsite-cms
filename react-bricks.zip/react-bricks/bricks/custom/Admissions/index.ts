export { Admissions as default } from './Admisions'
