export { TermsOfService as default } from './TermsOfService'
