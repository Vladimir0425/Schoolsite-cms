export { Contact as default } from './Contact'
